package ai.arena.shariaastro.app

import android.content.Context
import org.json.JSONArray
import java.time.Instant
import java.util.UUID

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sharia_astro_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryEntry> {
        val raw = prefs.getString(KEY_ENTRIES, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    runCatching { add(UiResultJsonCodec.decodeEntry(obj)) }
                }
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    fun saveResult(result: UiResult): HistoryEntry {
        val entry = HistoryEntry(
            id = UUID.randomUUID().toString(),
            createdAt = Instant.now(),
            title = result.title,
            summary = result.summary,
            result = result
        )
        val entries = (listOf(entry) + load()).take(MAX_ENTRIES)
        persist(entries)
        return entry
    }

    fun delete(id: String) {
        persist(load().filterNot { it.id == id })
    }

    fun clear() {
        persist(emptyList())
    }

    private fun persist(entries: List<HistoryEntry>) {
        val arr = JSONArray()
        entries.sortedByDescending { it.createdAt }.forEach { arr.put(UiResultJsonCodec.encodeEntry(it)) }
        prefs.edit().putString(KEY_ENTRIES, arr.toString()).apply()
    }

    companion object {
        private const val KEY_ENTRIES = "entries"
        private const val MAX_ENTRIES = 100
    }
}
