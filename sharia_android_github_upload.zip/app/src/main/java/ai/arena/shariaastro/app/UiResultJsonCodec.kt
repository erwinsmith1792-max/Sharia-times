package ai.arena.shariaastro.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

object UiResultJsonCodec {
    fun encodeResult(result: UiResult): JSONObject = JSONObject().apply {
        put("title", result.title)
        put("summary", result.summary)
        put("errors", JSONArray(result.errors))
        put("warnings", JSONArray(result.warnings))
        put("tables", JSONArray().apply {
            result.tables.forEach { table ->
                put(JSONObject().apply {
                    put("title", table.title)
                    put("headers", JSONArray(table.headers))
                    put("rows", JSONArray().apply {
                        table.rows.forEach { row -> put(JSONArray(row)) }
                    })
                })
            }
        })
    }

    fun decodeResult(json: JSONObject): UiResult = UiResult(
        title = json.optString("title"),
        summary = json.optStringOrNull("summary"),
        errors = json.optJSONArray("errors").toStringList(),
        warnings = json.optJSONArray("warnings").toStringList(),
        tables = buildList {
            val tables = json.optJSONArray("tables") ?: JSONArray()
            for (i in 0 until tables.length()) {
                val t = tables.optJSONObject(i) ?: continue
                val rowsJson = t.optJSONArray("rows") ?: JSONArray()
                add(
                    ResultTable(
                        title = t.optString("title"),
                        headers = t.optJSONArray("headers").toStringList(),
                        rows = buildList {
                            for (r in 0 until rowsJson.length()) {
                                add(rowsJson.optJSONArray(r).toStringList())
                            }
                        }
                    )
                )
            }
        }
    )

    fun encodeEntry(entry: HistoryEntry): JSONObject = JSONObject().apply {
        put("id", entry.id)
        put("createdAt", entry.createdAt.toString())
        put("title", entry.title)
        put("summary", entry.summary)
        put("result", encodeResult(entry.result))
    }

    fun decodeEntry(json: JSONObject): HistoryEntry = HistoryEntry(
        id = json.optString("id"),
        createdAt = runCatching { Instant.parse(json.optString("createdAt")) }.getOrDefault(Instant.EPOCH),
        title = json.optString("title"),
        summary = json.optStringOrNull("summary"),
        result = decodeResult(json.getJSONObject("result"))
    )

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) add(optString(i))
        }
    }

    private fun JSONObject.optStringOrNull(name: String): String? =
        if (has(name) && !isNull(name)) optString(name) else null
}
