package ai.arena.shariaastro.app

data class ResultTable(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>
)

data class UiResult(
    val title: String,
    val summary: String? = null,
    val tables: List<ResultTable> = emptyList(),
    val warnings: List<String> = emptyList(),
    val errors: List<String> = emptyList()
) {
    companion object {
        fun message(title: String, message: String) = UiResult(title = title, summary = message)
        fun loading(message: String) = UiResult(title = "جارٍ التنفيذ", summary = message)
    }
}

fun initialUiResult(): UiResult = UiResult.message(
    title = "جاهز",
    message = """
أدخل البيانات ثم اضغط حساب.

للحساب الفعلي أضف ملف بيانات Orekit/JPL باسم:
app/src/main/assets/orekit-data.zip

ينبغي أن يحتوي الملف على بيانات Orekit الأساسية وملف JPL ephemeris ثنائي مناسب.
""".trimIndent()
)

fun missingOrekitDataResult(): UiResult = UiResult.message(
    title = "ملف بيانات Orekit غير موجود",
    message = """
يمكنك الآن استيراد الملف من داخل التطبيق عبر زر:
استيراد orekit-data.zip

أو تضمينه قبل البناء في:
app/src/main/assets/orekit-data.zip

يجب أن يحتوي الملف على:
- بيانات orekit-data الأساسية.
- ملف JPL DE ephemeris ثنائي للشمس والقمر، مثل DE430/DE440 بصيغة يتعرف عليها Orekit.
""".trimIndent()
)
