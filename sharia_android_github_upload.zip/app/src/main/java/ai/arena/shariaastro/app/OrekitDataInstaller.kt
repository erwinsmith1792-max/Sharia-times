package ai.arena.shariaastro.app

import android.content.Context
import android.net.Uri
import java.io.File

object OrekitDataInstaller {
    private const val ASSET_ZIP = "orekit-data.zip"
    private const val IMPORTED_ZIP = "imported-orekit-data.zip"

    /**
     * يرجع ملف بيانات Orekit المتاح حالياً.
     * الأولوية للملف المستورد من الهاتف، ثم الملف المضمّن داخل assets إن وجد.
     */
    fun ensureOrekitDataZip(context: Context): File? {
        getImportedOrekitDataZip(context)?.let { return it }
        return installBundledAssetIfAvailable(context)
    }

    fun getImportedOrekitDataZip(context: Context): File? {
        val file = File(context.filesDir, IMPORTED_ZIP)
        return if (file.exists() && file.length() > 0L) file else null
    }

    fun hasOrekitData(context: Context): Boolean = ensureOrekitDataZip(context) != null

    fun orekitDataStatus(context: Context): String {
        getImportedOrekitDataZip(context)?.let {
            return "ملف Orekit مستورد من الهاتف: ${formatSize(it.length())}"
        }
        val bundled = installBundledAssetIfAvailable(context)
        return if (bundled != null) {
            "ملف Orekit مضمّن داخل التطبيق: ${formatSize(bundled.length())}"
        } else {
            "ملف Orekit غير موجود. استورد orekit-data.zip من الهاتف."
        }
    }

    /**
     * يستورد ملف orekit-data.zip من Storage Access Framework إلى ملفات التطبيق الداخلية.
     */
    fun importOrekitDataZip(context: Context, uri: Uri): File {
        val out = File(context.filesDir, IMPORTED_ZIP)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "تعذر فتح الملف المحدد." }
            out.outputStream().use { output -> input.copyTo(output) }
        }
        require(out.exists() && out.length() > 0L) { "تم استيراد ملف فارغ أو غير صالح." }
        return out
    }

    fun deleteImportedOrekitData(context: Context): Boolean = File(context.filesDir, IMPORTED_ZIP).delete()

    private fun installBundledAssetIfAvailable(context: Context): File? {
        val available = try {
            context.assets.open(ASSET_ZIP).close()
            true
        } catch (_: Exception) {
            false
        }
        if (!available) return null

        val out = File(context.filesDir, ASSET_ZIP)
        if (out.exists() && out.length() > 0L) return out

        context.assets.open(ASSET_ZIP).use { input ->
            out.outputStream().use { output -> input.copyTo(output) }
        }
        return out
    }

    private fun formatSize(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return "%.2f MB".format(mb)
    }
}
