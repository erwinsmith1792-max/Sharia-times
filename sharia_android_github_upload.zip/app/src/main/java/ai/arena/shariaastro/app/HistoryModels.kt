package ai.arena.shariaastro.app

import java.time.Instant

data class HistoryEntry(
    val id: String,
    val createdAt: Instant,
    val title: String,
    val summary: String?,
    val result: UiResult
)
