package ai.arena.shariaastro.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ai.arena.shariaastro.LegalSolarDayCalculator
import ai.arena.shariaastro.LegalSolarDayResult
import ai.arena.shariaastro.LunarSolarConjunctionCalculator
import ai.arena.shariaastro.NominatimGeoResolver
import ai.arena.shariaastro.Observer
import ai.arena.shariaastro.OrekitEphemerisProvider
import ai.arena.shariaastro.ShariaTimeEngine
import ai.arena.shariaastro.TimeZoneMapResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

data class ShariaAstroUiState(
    val place: String = "تونس",
    val latitude: String = "36.8065",
    val longitude: String = "10.1815",
    val zoneId: String = "Africa/Tunis",
    val date: String = "2026-06-21",
    val time: String = "12:00",
    val year: String = "2026",
    val elevationMeters: String = "0.0",
    val temperatureC: String = "15.0",
    val pressureHpa: String = "1013.25",
    val applyAtmosphericRefraction: Boolean = true,
    val result: UiResult = initialUiResult(),
    val history: List<HistoryEntry> = emptyList(),
    val historyStatus: String? = null,
    val orekitDataStatus: String = "جارٍ التحقق من ملف Orekit...",
    val isBusy: Boolean = false
)

class ShariaAstroViewModel(application: Application) : AndroidViewModel(application) {
    private val _uiState = MutableStateFlow(ShariaAstroUiState())
    val uiState: StateFlow<ShariaAstroUiState> = _uiState.asStateFlow()

    private val timeZoneResolver by lazy { TimeZoneMapResolver() }
    private val geoResolver by lazy { NominatimGeoResolver() }
    private val historyStore by lazy { HistoryStore(getApplication()) }

    init {
        _uiState.update {
            it.copy(
                history = historyStore.load(),
                orekitDataStatus = OrekitDataInstaller.orekitDataStatus(getApplication())
            )
        }
    }

    fun updatePlace(v: String) = _uiState.update { it.copy(place = v) }
    fun updateLatitude(v: String) = _uiState.update { it.copy(latitude = v) }
    fun updateLongitude(v: String) = _uiState.update { it.copy(longitude = v) }
    fun updateZoneId(v: String) = _uiState.update { it.copy(zoneId = v) }
    fun updateDate(v: String) = _uiState.update { it.copy(date = v) }
    fun updateTime(v: String) = _uiState.update { it.copy(time = v) }
    fun updateYear(v: String) = _uiState.update { it.copy(year = v) }
    fun updateElevationMeters(v: String) = _uiState.update { it.copy(elevationMeters = v) }
    fun updateTemperatureC(v: String) = _uiState.update { it.copy(temperatureC = v) }
    fun updatePressureHpa(v: String) = _uiState.update { it.copy(pressureHpa = v) }
    fun updateApplyAtmosphericRefraction(v: Boolean) = _uiState.update { it.copy(applyAtmosphericRefraction = v) }

    fun importOrekitData(uri: Uri) {
        launchBusy("جارٍ استيراد ملف Orekit من الهاتف...") {
            val status = withContext(Dispatchers.IO) {
                val file = OrekitDataInstaller.importOrekitDataZip(getApplication(), uri)
                "تم استيراد ملف Orekit بنجاح: ${"%.2f".format(file.length() / (1024.0 * 1024.0))} MB"
            }
            _uiState.update {
                it.copy(
                    orekitDataStatus = OrekitDataInstaller.orekitDataStatus(getApplication()),
                    result = UiResult.message("استيراد ملف Orekit", status),
                    isBusy = false
                )
            }
        }
    }

    fun deleteImportedOrekitData() {
        launchBusy("جارٍ حذف ملف Orekit المستورد...") {
            withContext(Dispatchers.IO) { OrekitDataInstaller.deleteImportedOrekitData(getApplication()) }
            val status = OrekitDataInstaller.orekitDataStatus(getApplication())
            _uiState.update {
                it.copy(
                    orekitDataStatus = status,
                    result = UiResult.message("ملف Orekit", "تم حذف الملف المستورد إن كان موجوداً."),
                    isBusy = false
                )
            }
        }
    }

    fun searchPlace() {
        val place = uiState.value.place
        launchBusy("جارٍ البحث عن المنطقة عبر Nominatim...") {
            val found = withContext(Dispatchers.IO) { resolvePlaceAndZone(place) }
            if (found != null) {
                _uiState.update {
                    it.copy(
                        latitude = "%.6f".format(found.latitudeDeg),
                        longitude = "%.6f".format(found.longitudeDeg),
                        zoneId = found.zoneId ?: it.zoneId,
                        result = UiResult(
                            title = "نتيجة البحث الجغرافي",
                            summary = "تم العثور على المنطقة وتحديث البيانات.",
                            tables = listOf(
                                ResultTable(
                                    title = "بيانات الموقع",
                                    headers = listOf("البند", "القيمة"),
                                    rows = listOf(
                                        listOf("خط العرض", "%.6f".format(found.latitudeDeg)),
                                        listOf("خط الطول", "%.6f".format(found.longitudeDeg)),
                                        listOf("المنطقة الزمنية", found.zoneId ?: "تعذر تحديدها آلياً")
                                    )
                                )
                            )
                        ),
                        isBusy = false
                    )
                }
            } else {
                setResult(UiResult.message("فشل البحث", "لم أتمكن من العثور على المنطقة. جرّب اسماً أدق أو أدخل الإحداثيات يدوياً."))
            }
        }
    }

    fun resolveTimeZone() {
        val lat = uiState.value.latitude
        val lon = uiState.value.longitude
        launchBusy("جارٍ تحديد المنطقة الزمنية من الإحداثيات...") {
            val z = withContext(Dispatchers.IO) { resolveZone(lat, lon) }
            if (z != null) {
                _uiState.update {
                    it.copy(
                        zoneId = z,
                        result = UiResult(
                            title = "المنطقة الزمنية",
                            summary = "تم تحديد المنطقة الزمنية وسيُحتسب التوقيت الصيفي تلقائياً حسب التاريخ عبر java.time.",
                            tables = listOf(ResultTable("النتيجة", listOf("البند", "القيمة"), listOf(listOf("IANA ZoneId", z))))
                        ),
                        isBusy = false
                    )
                }
            } else {
                setResult(UiResult.message("تعذر التحديد", "تعذر تحديد المنطقة الزمنية من الإحداثيات الحالية. راجع خط العرض/الطول أو أدخل IANA Timezone يدوياً."))
            }
        }
    }

    fun calculateShariaTimes() {
        val s = uiState.value
        launchBusy("جارٍ حساب الأوقات الشرعية وأوقات الصلاة...") {
            val r = withContext(Dispatchers.IO) {
                calculateShariaTimesInternal(
                    s.latitude,
                    s.longitude,
                    s.zoneId,
                    s.date,
                    s.time,
                    s.elevationMeters,
                    s.temperatureC,
                    s.pressureHpa,
                    s.applyAtmosphericRefraction
                )
            }
            setResult(r)
        }
    }

    fun calculateConjunctions() {
        val s = uiState.value
        launchBusy("جارٍ حساب الاقترانات القمرية-الشمسية...") {
            val r = withContext(Dispatchers.IO) {
                calculateConjunctionsInternal(
                    s.latitude,
                    s.longitude,
                    s.zoneId,
                    s.year,
                    s.elevationMeters,
                    s.temperatureC,
                    s.pressureHpa,
                    s.applyAtmosphericRefraction
                )
            }
            setResult(r)
        }
    }

    fun saveCurrentResultToHistory() {
        val current = uiState.value.result
        viewModelScope.launch(Dispatchers.IO) {
            val entry = historyStore.saveResult(current)
            val history = historyStore.load()
            _uiState.update {
                it.copy(
                    history = history,
                    historyStatus = "تم حفظ النتيجة في السجل: ${entry.title}"
                )
            }
        }
    }

    fun openHistoryEntry(id: String) {
        val entry = uiState.value.history.firstOrNull { it.id == id } ?: return
        _uiState.update {
            it.copy(
                result = entry.result,
                historyStatus = "تم فتح نتيجة محفوظة من السجل."
            )
        }
    }

    fun deleteHistoryEntry(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            historyStore.delete(id)
            val history = historyStore.load()
            _uiState.update { it.copy(history = history, historyStatus = "تم حذف عنصر من السجل.") }
        }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            historyStore.clear()
            _uiState.update { it.copy(history = emptyList(), historyStatus = "تم مسح السجل المحلي.") }
        }
    }

    private fun launchBusy(message: String, block: suspend () -> Unit) {
        _uiState.update { it.copy(isBusy = true, result = UiResult.loading(message)) }
        viewModelScope.launch {
            try {
                block()
            } catch (t: Throwable) {
                setResult(UiResult.message("خطأ", t.message ?: t::class.java.simpleName))
            }
        }
    }

    private fun setResult(result: UiResult) {
        _uiState.update { it.copy(result = result, isBusy = false, historyStatus = null) }
    }

    private data class ResolvedPlaceForUi(val latitudeDeg: Double, val longitudeDeg: Double, val zoneId: String?)

    private fun resolvePlaceAndZone(name: String): ResolvedPlaceForUi? = runCatching {
        val first = geoResolver.resolvePlace(name).firstOrNull() ?: return@runCatching null
        val zone = runCatching { timeZoneResolver.resolve(first.latitudeDeg, first.longitudeDeg).id }.getOrNull()
        ResolvedPlaceForUi(first.latitudeDeg, first.longitudeDeg, zone)
    }.getOrNull()

    private fun resolveZone(latText: String, lonText: String): String? = runCatching {
        timeZoneResolver.resolve(latText.toDouble(), lonText.toDouble()).id
    }.getOrNull()

    private fun calculateShariaTimesInternal(
        latText: String,
        lonText: String,
        zoneText: String,
        dateText: String,
        timeText: String,
        elevationText: String,
        temperatureText: String,
        pressureText: String,
        applyRefraction: Boolean
    ): UiResult = runCatching {
        val data = OrekitDataInstaller.ensureOrekitDataZip(getApplication()) ?: return missingOrekitDataResult()
        val lat = latText.toDouble()
        val lon = lonText.toDouble()
        val zone = ZoneId.of(zoneText.trim())
        val localDate = LocalDate.parse(dateText)
        val localTime = LocalTime.parse(timeText)
        val elevation = elevationText.toDouble()
        val temperature = temperatureText.toDouble()
        val pressure = pressureText.toDouble()

        val provider = OrekitEphemerisProvider.create(data, applyAtmosphericRefraction = applyRefraction)
        val observer = Observer(
            latitudeDeg = lat,
            longitudeDeg = lon,
            elevationMeters = elevation,
            temperatureC = temperature,
            pressureHpa = pressure
        )
        val dayCalc = LegalSolarDayCalculator(provider, observer, zone)

        when (val r = dayCalc.calculate(localDate)) {
            is LegalSolarDayResult.Failure -> UiResult(
                title = "فشل حساب اليوم الشرعي",
                errors = r.errors,
                warnings = r.partialWarnings
            )

            is LegalSolarDayResult.Success -> {
                val anchors = r.anchors
                val input = java.time.ZonedDateTime.of(localDate, localTime, zone)
                val sharia = ShariaTimeEngine.compute(input, anchors)
                val prayers = ShariaTimeEngine.prayerTimes(anchors)

                UiResult(
                    title = "نتائج الأوقات الشرعية والصلوات",
                    summary = "حُسبت النتائج للموقع: $lat, $lon — المنطقة الزمنية: ${zone.id}",
                    tables = listOf(
                        ResultTable(
                            title = "إعدادات النموذج",
                            headers = listOf("البند", "القيمة"),
                            rows = listOf(
                                listOf("ارتفاع الموقع", "$elevation م"),
                                listOf("درجة الحرارة", "$temperature °C"),
                                listOf("الضغط الجوي", "$pressure hPa"),
                                listOf("الانكسار الجوي", if (applyRefraction) "مفعّل" else "معطّل")
                            )
                        ),
                        ResultTable(
                            title = "الأحداث الشرعية الشمسية",
                            headers = listOf("الحدث", "التوقيت المحلي"),
                            rows = listOf(
                                listOf("الشروق الشرعي", fmt(anchors.sunrise)),
                                listOf("الظهر الشرعي، مركز الشمس على Az=180°", fmt(anchors.noon)),
                                listOf("دخول صلاة الظهر، تماس الحافة غرباً", anchors.dhuhrPrayerStart?.let { fmt(it) } ?: "غير متاح؛ استُخدم وقت المركز مؤقتاً"),
                                listOf("الغروب الشرعي", fmt(anchors.sunset)),
                                listOf("منتصف الليل الشرعي القريب", fmt(anchors.legalMidnightNearOfficialMidnight)),
                                listOf("منتصف الليل الشرعي التالي", fmt(anchors.legalMidnightNearNextOfficialMidnight))
                            )
                        ),
                        ResultTable(
                            title = "الوقت الشرعي للتوقيت المُدخل",
                            headers = listOf("البند", "القيمة"),
                            rows = listOf(
                                listOf("التوقيت المُدخل", fmt(input)),
                                listOf("الوصف", sharia.label),
                                listOf("القيمة الرقمية", "%.6f ساعة شرعية".format(sharia.value)),
                                listOf("الفترة", sharia.segment)
                            )
                        ),
                        ResultTable(
                            title = "أوقات الصلاة",
                            headers = listOf("الصلاة", "دخول الوقت", "خروج الوقت"),
                            rows = listOf(
                                listOf("الفجر", fmt(prayers.fajrStart), fmt(prayers.fajrEnd)),
                                listOf("الظهر", fmt(prayers.dhuhrStart), fmt(prayers.dhuhrEnd)),
                                listOf("العصر", fmt(prayers.asrStart), fmt(prayers.asrEnd)),
                                listOf("المغرب", fmt(prayers.maghribStart), fmt(prayers.maghribEnd)),
                                listOf("العشاء", fmt(prayers.ishaStart), fmt(prayers.ishaEnd))
                            )
                        )
                    ),
                    warnings = r.warnings
                )
            }
        }
    }.getOrElse { UiResult.message("خطأ", it.message ?: it::class.java.simpleName) }

    private fun calculateConjunctionsInternal(
        latText: String,
        lonText: String,
        zoneText: String,
        yearText: String,
        elevationText: String,
        temperatureText: String,
        pressureText: String,
        applyRefraction: Boolean
    ): UiResult = runCatching {
        val data = OrekitDataInstaller.ensureOrekitDataZip(getApplication()) ?: return missingOrekitDataResult()
        val lat = latText.toDouble()
        val lon = lonText.toDouble()
        val zone = ZoneId.of(zoneText.trim())
        val year = yearText.toInt()
        val elevation = elevationText.toDouble()
        val temperature = temperatureText.toDouble()
        val pressure = pressureText.toDouble()

        val provider = OrekitEphemerisProvider.create(data, applyAtmosphericRefraction = applyRefraction)
        val observer = Observer(
            latitudeDeg = lat,
            longitudeDeg = lon,
            elevationMeters = elevation,
            temperatureC = temperature,
            pressureHpa = pressure
        )
        val calc = LunarSolarConjunctionCalculator(provider, observer, zone)
        val xs = calc.conjunctionsForYear(year)
        val ds = calc.durationsBetween(xs)

        UiResult(
            title = "الاقترانات القمرية-الشمسية لسنة $year",
            summary = if (xs.isEmpty()) "لم تُعثر نتائج ضمن معايير الترشيح الحالية." else "عدد الاقترانات المحسوبة: ${xs.size}",
            tables = listOf(
                ResultTable(
                    title = "إعدادات النموذج",
                    headers = listOf("البند", "القيمة"),
                    rows = listOf(
                        listOf("ارتفاع الموقع", "$elevation م"),
                        listOf("درجة الحرارة", "$temperature °C"),
                        listOf("الضغط الجوي", "$pressure hPa"),
                        listOf("الانكسار الجوي", if (applyRefraction) "مفعّل" else "معطّل")
                    )
                ),
                ResultTable(
                    title = "جدول الاقترانات والمدد بينها",
                    headers = listOf("#", "توقيت الاقتران", "البعد الزاوي", "المدة إلى التالي"),
                    rows = xs.mapIndexed { i, c ->
                        listOf(
                            (i + 1).toString(),
                            fmt(c.time),
                            "%.4f°".format(c.elongationDeg),
                            ds.getOrNull(i)?.let { "${it.toDays()} يوم، ${it.toHoursPart()} ساعة، ${it.toMinutesPart()} دقيقة" } ?: "—"
                        )
                    }
                )
            )
        )
    }.getOrElse { UiResult.message("خطأ", it.message ?: it::class.java.simpleName) }

    private fun fmt(t: java.time.ZonedDateTime): String =
        t.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z"))
}
