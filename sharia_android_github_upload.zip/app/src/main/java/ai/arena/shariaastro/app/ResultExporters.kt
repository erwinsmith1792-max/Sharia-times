package ai.arena.shariaastro.app

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

enum class ExportFormat(val extension: String, val mimeType: String, val arabicLabel: String) {
    TEXT("txt", "text/plain", "نص"),
    CSV("csv", "text/csv", "CSV"),
    JSON("json", "application/json", "JSON")
}

object ResultExporters {
    fun export(result: UiResult, format: ExportFormat): String = when (format) {
        ExportFormat.TEXT -> toPlainText(result)
        ExportFormat.CSV -> toCsv(result)
        ExportFormat.JSON -> toJson(result)
    }

    fun fileName(result: UiResult, format: ExportFormat): String {
        val safeTitle = result.title
            .replace(Regex("[^\\p{L}\\p{N}._-]+"), "_")
            .trim('_')
            .ifBlank { "sharia_astro_result" }
        val stamp = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
        return "${safeTitle}_$stamp.${format.extension}"
    }

    fun toPlainText(result: UiResult): String = buildString {
        appendLine(result.title)
        appendLine("=".repeat(result.title.length.coerceAtLeast(8)))
        result.summary?.let {
            appendLine()
            appendLine(it)
        }
        if (result.errors.isNotEmpty()) {
            appendLine()
            appendLine("الأخطاء:")
            result.errors.forEach { appendLine("- $it") }
        }
        result.tables.forEach { table ->
            appendLine()
            appendLine(table.title)
            appendLine("-".repeat(table.title.length.coerceAtLeast(8)))
            appendLine(table.headers.joinToString(" | "))
            appendLine(table.headers.joinToString(" | ") { "---" })
            table.rows.forEach { row -> appendLine(row.joinToString(" | ")) }
        }
        if (result.warnings.isNotEmpty()) {
            appendLine()
            appendLine("التحذيرات:")
            result.warnings.forEach { appendLine("- $it") }
        }
    }

    fun toCsv(result: UiResult): String = buildString {
        appendLine(listOf("نوع السطر", "الجدول", "العمود 1", "العمود 2", "العمود 3", "العمود 4", "العمود 5").toCsvRow())
        appendLine(listOf("عنوان", "", result.title).toCsvRow())
        result.summary?.let { appendLine(listOf("ملخص", "", it).toCsvRow()) }
        result.errors.forEach { appendLine(listOf("خطأ", "", it).toCsvRow()) }

        result.tables.forEach { table ->
            appendLine(listOf("جدول", table.title).toCsvRow())
            appendLine((listOf("رأس", table.title) + table.headers).toCsvRow())
            table.rows.forEach { row -> appendLine((listOf("بيانات", table.title) + row).toCsvRow()) }
        }
        result.warnings.forEach { appendLine(listOf("تحذير", "", it).toCsvRow()) }
    }

    fun toJson(result: UiResult): String = buildString {
        appendLine("{")
        appendLine("  \"title\": ${result.title.json()},")
        appendLine("  \"summary\": ${result.summary?.json() ?: "null"},")
        appendLine("  \"errors\": ${result.errors.toJsonArray()},")
        appendLine("  \"warnings\": ${result.warnings.toJsonArray()},")
        appendLine("  \"tables\": [")
        result.tables.forEachIndexed { tableIndex, table ->
            appendLine("    {")
            appendLine("      \"title\": ${table.title.json()},")
            appendLine("      \"headers\": ${table.headers.toJsonArray()},")
            appendLine("      \"rows\": [")
            table.rows.forEachIndexed { rowIndex, row ->
                append("        ${row.toJsonArray()}")
                if (rowIndex != table.rows.lastIndex) append(",")
                appendLine()
            }
            appendLine("      ]")
            append("    }")
            if (tableIndex != result.tables.lastIndex) append(",")
            appendLine()
        }
        appendLine("  ]")
        appendLine("}")
    }

    private fun List<String>.toCsvRow(): String = joinToString(",") { it.csv() }

    private fun String.csv(): String {
        val escaped = replace("\"", "\"\"")
        return "\"$escaped\""
    }

    private fun List<String>.toJsonArray(): String = joinToString(prefix = "[", postfix = "]") { it.json() }

    private fun String.json(): String = buildString {
        append('"')
        for (c in this@json) {
            when (c) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(c)
            }
        }
        append('"')
    }
}
