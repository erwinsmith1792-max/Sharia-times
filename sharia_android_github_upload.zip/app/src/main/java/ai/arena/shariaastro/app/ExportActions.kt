package ai.arena.shariaastro.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.nio.charset.StandardCharsets

object ExportActions {
    fun exportAndShare(context: Context, result: UiResult, format: ExportFormat) {
        runCatching {
            val content = ResultExporters.export(result, format)
            val file = writeExportFile(context, result, format, content)
            shareFile(context, file, format)
        }.onFailure {
            Toast.makeText(context, "تعذر تصدير النتائج: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun exportToAppFiles(context: Context, result: UiResult, format: ExportFormat): File {
        val content = ResultExporters.export(result, format)
        return writeExportFile(context, result, format, content)
    }

    private fun writeExportFile(context: Context, result: UiResult, format: ExportFormat, content: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, ResultExporters.fileName(result, format))
        file.writeText(content, StandardCharsets.UTF_8)
        return file
    }

    private fun shareFile(context: Context, file: File, format: ExportFormat) {
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = format.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "تصدير نتائج الأوقات الشرعية")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة ملف ${format.arabicLabel}"))
    }
}
