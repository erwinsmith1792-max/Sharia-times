package ai.arena.shariaastro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        ShariaAstroScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun ShariaAstroScreen(viewModel: ShariaAstroViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsState()
    val orekitFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importOrekitData(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تطبيق الأوقات الشرعية", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("الواجهة مفصولة الآن عن منطق الحساب عبر ViewModel، والنتائج تُعرض في جداول منظمة.")

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("بيانات Orekit/JPL", fontWeight = FontWeight.Bold)
                Text(state.orekitDataStatus)
                Text(
                    "للحساب الفلكي الحقيقي اختر ملف orekit-data.zip من ذاكرة الهاتف. يجب أن يحتوي على بيانات Orekit الأساسية وملف JPL DE ephemeris.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { orekitFilePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        enabled = !state.isBusy
                    ) { Text("استيراد orekit-data.zip") }
                    Button(
                        onClick = viewModel::deleteImportedOrekitData,
                        enabled = !state.isBusy
                    ) { Text("حذف الملف المستورد") }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الموقع والزمن", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = state.place,
                    onValueChange = viewModel::updatePlace,
                    label = { Text("اسم المنطقة") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isBusy
                )
                Button(onClick = viewModel::searchPlace, enabled = !state.isBusy) { Text("بحث عن الإحداثيات") }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state.latitude,
                        onValueChange = viewModel::updateLatitude,
                        label = { Text("خط العرض") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                    OutlinedTextField(
                        value = state.longitude,
                        onValueChange = viewModel::updateLongitude,
                        label = { Text("خط الطول") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                }

                OutlinedTextField(
                    value = state.zoneId,
                    onValueChange = viewModel::updateZoneId,
                    label = { Text("IANA Timezone") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isBusy
                )
                Button(onClick = viewModel::resolveTimeZone, enabled = !state.isBusy) { Text("تحديد المنطقة الزمنية من الإحداثيات") }

                Text("إعدادات النموذج الظاهري", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state.elevationMeters,
                        onValueChange = viewModel::updateElevationMeters,
                        label = { Text("الارتفاع م") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                    OutlinedTextField(
                        value = state.temperatureC,
                        onValueChange = viewModel::updateTemperatureC,
                        label = { Text("الحرارة °C") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                }
                OutlinedTextField(
                    value = state.pressureHpa,
                    onValueChange = viewModel::updatePressureHpa,
                    label = { Text("الضغط الجوي hPa") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isBusy
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Checkbox(
                        checked = state.applyAtmosphericRefraction,
                        onCheckedChange = viewModel::updateApplyAtmosphericRefraction,
                        enabled = !state.isBusy
                    )
                    Text("تفعيل الانكسار الجوي القياسي")
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state.date,
                        onValueChange = viewModel::updateDate,
                        label = { Text("التاريخ YYYY-MM-DD") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                    OutlinedTextField(
                        value = state.time,
                        onValueChange = viewModel::updateTime,
                        label = { Text("الوقت HH:mm") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    )
                }
                Button(onClick = viewModel::calculateShariaTimes, enabled = !state.isBusy) { Text("حساب الأوقات والصلوات") }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("حساب الاقترانات القمرية-الشمسية", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = state.year,
                    onValueChange = viewModel::updateYear,
                    label = { Text("السنة") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isBusy
                )
                Button(onClick = viewModel::calculateConjunctions, enabled = !state.isBusy) { Text("حساب الاقترانات") }
            }
        }

        Spacer(Modifier.height(8.dp))
        ResultPanel(
            result = state.result,
            onSaveToHistory = viewModel::saveCurrentResultToHistory
        )
        HistoryPanel(
            history = state.history,
            status = state.historyStatus,
            onOpen = viewModel::openHistoryEntry,
            onDelete = viewModel::deleteHistoryEntry,
            onClear = viewModel::clearHistory,
            isBusy = state.isBusy
        )
    }
}

@Composable
private fun ResultPanel(
    result: UiResult,
    onSaveToHistory: () -> Unit
) {
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(result.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            result.summary?.let { Text(it) }

            result.errors.forEach { Text("خطأ: $it", color = MaterialTheme.colorScheme.error) }
            result.tables.forEach { ResultTableView(it) }

            HorizontalDivider()
            Text("حفظ وتصدير النتائج", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSaveToHistory) { Text("حفظ في السجل") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ExportActions.exportAndShare(context, result, ExportFormat.TEXT) }) { Text("نص") }
                Button(onClick = { ExportActions.exportAndShare(context, result, ExportFormat.CSV) }) { Text("CSV") }
                Button(onClick = { ExportActions.exportAndShare(context, result, ExportFormat.JSON) }) { Text("JSON") }
            }

            if (result.warnings.isNotEmpty()) {
                HorizontalDivider()
                Text("تحذيرات", fontWeight = FontWeight.Bold)
                result.warnings.forEach { Text("- $it") }
            }
        }
    }
}

@Composable
private fun HistoryPanel(
    history: List<HistoryEntry>,
    status: String?,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onClear: () -> Unit,
    isBusy: Boolean
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("السجل المحلي للنتائج", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            status?.let { Text(it) }
            if (history.isEmpty()) {
                Text("لا توجد نتائج محفوظة بعد.")
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onClear, enabled = !isBusy) { Text("مسح السجل") }
                }
                history.forEach { entry ->
                    HorizontalDivider()
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(entry.title, fontWeight = FontWeight.Bold)
                        Text(formatHistoryTime(entry))
                        entry.summary?.let { Text(it) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onOpen(entry.id) }, enabled = !isBusy) { Text("فتح") }
                            Button(onClick = { onDelete(entry.id) }, enabled = !isBusy) { Text("حذف") }
                        }
                    }
                }
            }
        }
    }
}

private fun formatHistoryTime(entry: HistoryEntry): String =
    entry.createdAt.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z"))

@Composable
private fun ResultTableView(table: ResultTable) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(table.title, fontWeight = FontWeight.Bold)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            val colWidth = 170.dp
            Row(modifier = Modifier.fillMaxWidth()) {
                table.headers.forEach { h ->
                    Text(
                        h,
                        modifier = Modifier
                            .width(colWidth)
                            .padding(6.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            HorizontalDivider()
            table.rows.forEach { row ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    row.forEach { cell ->
                        Text(
                            cell,
                            modifier = Modifier
                                .width(colWidth)
                                .padding(6.dp),
                            fontFamily = if (cell.any { it.isDigit() }) FontFamily.Monospace else FontFamily.Default
                        )
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
