package ai.arena.shariaastro.app

import org.junit.Assert.assertTrue
import org.junit.Test

class ResultExportersTest {
    private val sample = UiResult(
        title = "اختبار التصدير",
        summary = "ملخص تجريبي",
        tables = listOf(
            ResultTable(
                title = "جدول",
                headers = listOf("الحدث", "الوقت"),
                rows = listOf(
                    listOf("الشروق", "06:00"),
                    listOf("الغروب", "18:00")
                )
            )
        ),
        warnings = listOf("تحذير تجريبي")
    )

    @Test
    fun plainTextContainsTableData() {
        val text = ResultExporters.toPlainText(sample)
        assertTrue(text.contains("اختبار التصدير"))
        assertTrue(text.contains("الشروق"))
        assertTrue(text.contains("06:00"))
    }

    @Test
    fun csvQuotesCellsAndContainsRows() {
        val csv = ResultExporters.toCsv(sample)
        assertTrue(csv.contains("\"الشروق\""))
        assertTrue(csv.contains("\"18:00\""))
    }

    @Test
    fun jsonContainsStructuredKeys() {
        val json = ResultExporters.toJson(sample)
        assertTrue(json.contains("\"title\""))
        assertTrue(json.contains("\"tables\""))
        assertTrue(json.contains("\"rows\""))
    }
}
