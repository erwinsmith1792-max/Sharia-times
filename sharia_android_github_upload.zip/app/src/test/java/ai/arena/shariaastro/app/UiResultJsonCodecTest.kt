package ai.arena.shariaastro.app

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant

class UiResultJsonCodecTest {
    @Test
    fun encodesAndDecodesResult() {
        val result = UiResult(
            title = "نتيجة",
            summary = "ملخص",
            tables = listOf(ResultTable("جدول", listOf("أ", "ب"), listOf(listOf("1", "2")))),
            warnings = listOf("تحذير")
        )

        val decoded = UiResultJsonCodec.decodeResult(UiResultJsonCodec.encodeResult(result))

        assertEquals(result.title, decoded.title)
        assertEquals(result.summary, decoded.summary)
        assertEquals(result.tables.first().rows.first()[1], decoded.tables.first().rows.first()[1])
        assertEquals(result.warnings.first(), decoded.warnings.first())
    }

    @Test
    fun encodesAndDecodesHistoryEntry() {
        val entry = HistoryEntry(
            id = "id-1",
            createdAt = Instant.parse("2026-06-21T12:00:00Z"),
            title = "محفوظ",
            summary = "ملخص",
            result = UiResult.message("محفوظ", "ملخص")
        )

        val decoded = UiResultJsonCodec.decodeEntry(UiResultJsonCodec.encodeEntry(entry))

        assertEquals(entry.id, decoded.id)
        assertEquals(entry.createdAt, decoded.createdAt)
        assertEquals(entry.result.title, decoded.result.title)
    }
}
