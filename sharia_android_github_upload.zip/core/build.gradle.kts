plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ai.arena.shariaastro.core"
    compileSdk = 35

    defaultConfig {
        minSdk = 26
    }
}

dependencies {
    implementation("org.orekit:orekit:13.1.6")

    implementation("us.dustinj.timezonemap:timezonemap:4.5") {
        exclude(group = "com.github.luben", module = "zstd-jni")
    }
    implementation("com.github.luben:zstd-jni:1.4.9-5@aar")

    testImplementation("junit:junit:4.13.2")
}
