package ai.arena.shariaastro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class TimeZoneAndDstTest {
    @Test
    fun javaTimeAppliesDstForIanaZone() {
        val paris = ZoneId.of("Europe/Paris")
        val winter = LocalDateTime.of(2026, 1, 15, 12, 0).atZone(paris)
        val summer = LocalDateTime.of(2026, 7, 15, 12, 0).atZone(paris)

        assertEquals(3600, winter.offset.totalSeconds)
        assertEquals(7200, summer.offset.totalSeconds)
    }

    @Test
    fun timeZoneMapResolverReturnsIanaZoneForTunisiaCoordinate() {
        val zone = TimeZoneMapResolver().resolve(36.8065, 10.1815)
        assertEquals("Africa/Tunis", zone.id)
    }

    @Test
    fun timeZoneMapResolverReturnsSomeValidZoneForOpenSeaFallback() {
        // نقطة بحرية قد ترجع Etc/GMT... حسب بيانات الحدود، المهم أن تكون ZoneId صالحة.
        val zone = TimeZoneMapResolver().resolve(0.0, 0.0)
        assertTrue(ZoneId.getAvailableZoneIds().contains(zone.id))
    }
}
