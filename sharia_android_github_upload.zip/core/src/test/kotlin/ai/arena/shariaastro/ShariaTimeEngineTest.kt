package ai.arena.shariaastro

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class ShariaTimeEngineTest {
    private val zone = ZoneId.of("Africa/Tunis")

    /**
     * يوم اصطناعي بسيط لتثبيت منطق التقسيمات بعيداً عن ephemeris:
     * sunrise=06:00, noon=11:00, sunset=17:00
     * delta1=1h, delta2=1h, D=05:00
     * legalMidnight=23:00 previous/near official, nextLegalMidnight=23:00 same day
     */
    private val anchors = LegalSolarAnchors(
        sunrise = zdt(2026, 6, 21, 6, 0),
        noon = zdt(2026, 6, 21, 11, 0),
        sunset = zdt(2026, 6, 21, 17, 0),
        legalMidnightNearOfficialMidnight = zdt(2026, 6, 20, 23, 0),
        legalMidnightNearNextOfficialMidnight = zdt(2026, 6, 21, 23, 0),
        dhuhrPrayerStart = zdt(2026, 6, 21, 11, 2)
    )

    @Test
    fun sunriseIsOneShariaHour() {
        val r = ShariaTimeEngine.compute(zdt(2026, 6, 21, 6, 0), anchors)
        assertEquals(1.0, r.value, 1e-9)
        assertEquals("طلوع الشمس", r.label)
    }

    @Test
    fun noonIsSixShariaHours() {
        val r = ShariaTimeEngine.compute(zdt(2026, 6, 21, 11, 0), anchors)
        assertEquals(6.0, r.value, 1e-9)
        assertEquals("تمام الضحى وبداية الظهر", r.label)
    }

    @Test
    fun sunsetIsTwelveShariaHours() {
        val r = ShariaTimeEngine.compute(zdt(2026, 6, 21, 17, 0), anchors)
        assertEquals(12.0, r.value, 1e-9)
        assertEquals("الغروب", r.label)
    }

    @Test
    fun prayerTimesUseDhuhrPrayerStartWhenAvailable() {
        val p = ShariaTimeEngine.prayerTimes(anchors)
        assertEquals(zdt(2026, 6, 21, 5, 0), p.fajrStart)
        assertEquals(zdt(2026, 6, 21, 11, 2), p.dhuhrStart)
        assertEquals(zdt(2026, 6, 21, 14, 15), p.asrStart)
        assertEquals(zdt(2026, 6, 21, 16, 45), p.asrEnd)
        assertEquals(zdt(2026, 6, 21, 18, 0), p.ishaStart)
    }

    private fun zdt(y: Int, m: Int, d: Int, h: Int, min: Int): ZonedDateTime =
        ZonedDateTime.of(y, m, d, h, min, 0, 0, zone)
}
