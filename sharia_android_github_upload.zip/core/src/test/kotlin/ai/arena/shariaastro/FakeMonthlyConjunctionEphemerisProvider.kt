package ai.arena.shariaastro

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * مزود اصطناعي لاختبار حاسب الاقترانات فقط.
 * يجعل القمر يعبر قرب موضع الشمس دورياً بفترة قمرية تقريبية.
 */
class FakeMonthlyConjunctionEphemerisProvider : EphemerisProvider {
    private val epoch = LocalDate.of(2026, 1, 1)

    override fun apparentSunMoonTopocentric(observer: Observer, time: java.time.ZonedDateTime): SunMoonApparent {
        val h = time.toLocalTime().toSecondOfDay().toDouble() / 3600.0
        val day = ChronoUnit.DAYS.between(epoch, time.toLocalDate()).toDouble() + h / 24.0

        val sunAz = normalize360(180.0 - 25.0 * sin(2.0 * PI * h / 24.0))
        val sunAlt = 35.0 + 20.0 * sin(2.0 * PI * (h - 6.0) / 24.0)

        // فرق زاوي يتغير دورياً؛ عندما يقترب من الصفر يصبح القمر قريباً من الشمس.
        val phaseOffset = 8.0 * sin(2.0 * PI * day / 29.530588)

        return SunMoonApparent(
            sunAzimuthDeg = sunAz,
            sunAltitudeDeg = sunAlt,
            moonAzimuthDeg = normalize360(sunAz + phaseOffset),
            moonAltitudeDeg = sunAlt + phaseOffset * 0.05,
            sunApparentRadiusDeg = 0.25,
            moonApparentRadiusDeg = 0.25
        )
    }

    private fun normalize360(x0: Double): Double {
        var x = x0 % 360.0
        if (x < 0.0) x += 360.0
        return x
    }
}
