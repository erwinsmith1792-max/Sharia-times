package ai.arena.shariaastro

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.ZoneId

class LunarSolarConjunctionCalculatorTest {
    @Test
    fun findsSyntheticConjunctionsAndPositiveDurations() {
        val calc = LunarSolarConjunctionCalculator(
            ephemeris = FakeMonthlyConjunctionEphemerisProvider(),
            observer = Observer(36.8065, 10.1815),
            zone = ZoneId.of("Africa/Tunis"),
            options = ConjunctionOptions(
                scanStep = Duration.ofHours(6),
                tolerance = Duration.ofSeconds(2),
                maxElongationDeg = 15.0,
                mergeWindow = Duration.ofDays(5)
            )
        )

        val xs = calc.conjunctionsForYear(2026)
        assertTrue("expected synthetic conjunctions", xs.isNotEmpty())
        assertTrue("expected several synthetic conjunctions", xs.size >= 8)

        val durations = calc.durationsBetween(xs)
        assertTrue(durations.all { !it.isNegative && !it.isZero })
    }
}
