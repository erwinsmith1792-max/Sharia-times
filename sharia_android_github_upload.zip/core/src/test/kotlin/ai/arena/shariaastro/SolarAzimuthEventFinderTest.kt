package ai.arena.shariaastro

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

class SolarAzimuthEventFinderTest {
    private val zone = ZoneId.of("Africa/Tunis")
    private val date = LocalDate.of(2026, 6, 21)
    private val observer = Observer(latitudeDeg = 36.8065, longitudeDeg = 10.1815)
    private val finder = SolarAzimuthEventFinder(
        ephemeris = FakeDailySunEphemerisProvider(),
        observer = observer,
        options = SolarEventOptions(scanStep = Duration.ofMinutes(10), tolerance = Duration.ofMillis(100))
    )

    @Test
    fun findsLegalSunriseAtKnownSyntheticTime() {
        val event = finder.findLegalSunrise(date, zone)
        assertNotNull(event)
        assertClose(ZonedDateTime.of(date, LocalTime.of(6, 0), zone), event!!.time, Duration.ofSeconds(2))
    }

    @Test
    fun findsLegalSunsetAtKnownSyntheticTime() {
        val event = finder.findLegalSunset(date, zone)
        assertNotNull(event)
        assertClose(ZonedDateTime.of(date, LocalTime.of(18, 0), zone), event!!.time, Duration.ofSeconds(2))
    }

    @Test
    fun findsNoonAzimuth180AboveHorizon() {
        val start = ZonedDateTime.of(date, LocalTime.of(6, 0), zone)
        val end = ZonedDateTime.of(date, LocalTime.of(18, 0), zone)
        val event = finder.findCenterAzimuth180(start, end, aboveHorizon = true)
        assertNotNull(event)
        assertClose(ZonedDateTime.of(date, LocalTime.NOON, zone), event!!.time, Duration.ofSeconds(2))
    }

    @Test
    fun findsMidnightAzimuth180BelowHorizon() {
        val officialMidnight = ZonedDateTime.of(date, LocalTime.MIDNIGHT, zone)
        val event = finder.findCenterAzimuth180(
            officialMidnight.minusHours(6),
            officialMidnight.plusHours(6),
            aboveHorizon = false,
            closestTo = officialMidnight
        )
        assertNotNull(event)
        assertClose(officialMidnight, event!!.time, Duration.ofSeconds(2))
    }

    @Test
    fun findsDhuhrPrayerAfterNoonAndBeforeSunset() {
        val noon = ZonedDateTime.of(date, LocalTime.NOON, zone)
        val sunset = ZonedDateTime.of(date, LocalTime.of(18, 0), zone)
        val event = finder.findDhuhrPrayerStartAfter(noon, sunset)
        assertNotNull(event)
        assertTrue(event!!.time.isAfter(noon))
        assertTrue(event.time.isBefore(sunset))
    }

    private fun assertClose(expected: ZonedDateTime, actual: ZonedDateTime, tolerance: Duration) {
        val diff = kotlin.math.abs(Duration.between(expected.toInstant(), actual.toInstant()).toMillis())
        assertTrue("expected=$expected actual=$actual diffMs=$diff", diff <= tolerance.toMillis())
    }
}
