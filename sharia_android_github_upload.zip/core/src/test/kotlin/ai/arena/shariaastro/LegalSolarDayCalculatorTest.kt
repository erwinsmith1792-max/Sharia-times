package ai.arena.shariaastro

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

class LegalSolarDayCalculatorTest {
    private val zone = ZoneId.of("Africa/Tunis")
    private val date = LocalDate.of(2026, 6, 21)

    @Test
    fun buildsLegalSolarAnchorsFromSyntheticEphemeris() {
        val calculator = LegalSolarDayCalculator(
            ephemeris = FakeDailySunEphemerisProvider(),
            observer = Observer(36.8065, 10.1815),
            zone = zone,
            options = SolarEventOptions(scanStep = Duration.ofMinutes(10), tolerance = Duration.ofMillis(100))
        )

        val result = calculator.calculate(date)
        assertTrue(result is LegalSolarDayResult.Success)
        val anchors = (result as LegalSolarDayResult.Success).anchors

        assertClose(ZonedDateTime.of(date, LocalTime.of(6, 0), zone), anchors.sunrise, Duration.ofSeconds(2))
        assertClose(ZonedDateTime.of(date, LocalTime.NOON, zone), anchors.noon, Duration.ofSeconds(2))
        assertClose(ZonedDateTime.of(date, LocalTime.of(18, 0), zone), anchors.sunset, Duration.ofSeconds(2))
        assertClose(ZonedDateTime.of(date, LocalTime.MIDNIGHT, zone), anchors.legalMidnightNearOfficialMidnight, Duration.ofSeconds(2))
        assertTrue("dhuhrPrayerStart should be available in synthetic model", anchors.dhuhrPrayerStart != null)
        assertTrue(anchors.dhuhrPrayerStart!!.isAfter(anchors.noon))
        assertTrue(anchors.dhuhrPrayerStart.isBefore(anchors.sunset))
    }

    private fun assertClose(expected: ZonedDateTime, actual: ZonedDateTime, tolerance: Duration) {
        val diff = kotlin.math.abs(Duration.between(expected.toInstant(), actual.toInstant()).toMillis())
        assertTrue("expected=$expected actual=$actual diffMs=$diff", diff <= tolerance.toMillis())
    }
}
