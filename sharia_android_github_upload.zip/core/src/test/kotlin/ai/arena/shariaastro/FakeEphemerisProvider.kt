package ai.arena.shariaastro

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * مزود فلكي اصطناعي لاختبارات النواة فقط.
 * ليس نموذجاً فلكياً حقيقياً، بل دوال سلسة تعطي أحداثاً معروفة:
 * - شروق شرعي عند 06:00 تقريباً.
 * - غروب شرعي عند 18:00 تقريباً.
 * - Azimuth=180° فوق الأفق عند 12:00.
 * - Azimuth=180° تحت الأفق عند 00:00.
 */
class FakeDailySunEphemerisProvider : EphemerisProvider {
    override fun apparentSunMoonTopocentric(observer: Observer, time: java.time.ZonedDateTime): SunMoonApparent {
        val h = time.toLocalTime().toSecondOfDay().toDouble() / 3600.0 + time.nano / 3_600_000_000_000.0

        // ارتفاع مركز الشمس: عند 06:00 و18:00 يساوي -نصف القطر، فتكون الحافة العليا على الأفق.
        val sunRadius = 0.25
        val sunAltitude = 6.0 - abs(h - 12.0) - sunRadius

        // Az=180 عند منتصف الليل والظهر. بعد الظهر يصبح az>180 لمحاكاة جهة الغرب.
        val sunAzimuth = normalize360(180.0 - 20.0 * sin(2.0 * PI * h / 24.0))

        return SunMoonApparent(
            sunAzimuthDeg = sunAzimuth,
            sunAltitudeDeg = sunAltitude,
            moonAzimuthDeg = normalize360(sunAzimuth + 5.0),
            moonAltitudeDeg = sunAltitude + 2.0,
            sunApparentRadiusDeg = sunRadius,
            moonApparentRadiusDeg = 0.25
        )
    }

    private fun normalize360(x0: Double): Double {
        var x = x0 % 360.0
        if (x < 0.0) x += 360.0
        return x
    }
}
