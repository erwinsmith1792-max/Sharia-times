package ai.arena.shariaastro

import org.hipparchus.geometry.euclidean.threed.Vector3D
import org.hipparchus.util.FastMath
import org.orekit.bodies.CelestialBody
import org.orekit.bodies.CelestialBodyFactory
import org.orekit.bodies.GeodeticPoint
import org.orekit.bodies.OneAxisEllipsoid
import org.orekit.data.DataContext
import org.orekit.data.DirectoryCrawler
import org.orekit.data.ZipJarCrawler
import org.orekit.frames.Frame
import org.orekit.frames.FramesFactory
import org.orekit.frames.TopocentricFrame
import org.orekit.time.AbsoluteDate
import org.orekit.time.TimeScalesFactory
import org.orekit.utils.Constants
import java.io.File
import java.time.ZoneOffset
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.tan

/**
 * مزوّد مواقع الشمس والقمر اعتماداً على Orekit + ملفات بيانات Orekit/JPL.
 *
 * المطلوب في مجلد البيانات:
 * - orekit-data.zip أو مجلد orekit-data يحتوي EOP/UTC/Frames data.
 * - ملف JPL ephemeris ثنائي مثل DE430/DE440 بالاسم الذي يتعرف عليه Orekit، مثل lnxp*.4xx أو unxp*.4xx.
 *
 * ملاحظة الدقة:
 * - الموضع topocentric هندسي من Orekit.
 * - نضيف انكساراً جوياً قياسياً إلى ارتفاع المركز ليصبح الارتفاع apparent بصرياً قرب الأفق.
 * - نصف قطر الشمس/القمر يحسب من المسافة topocentric والأنصاف الحقيقية.
 */
class OrekitEphemerisProvider private constructor(
    private val inertialFrame: Frame = FramesFactory.getGCRF(),
    private val earthFrame: Frame = FramesFactory.getITRF(org.orekit.utils.IERSConventions.IERS_2010, true),
    private val applyAtmosphericRefraction: Boolean = true
) : EphemerisProvider {

    private val earth = OneAxisEllipsoid(
        Constants.WGS84_EARTH_EQUATORIAL_RADIUS,
        Constants.WGS84_EARTH_FLATTENING,
        earthFrame
    )

    private val sun: CelestialBody by lazy { CelestialBodyFactory.getSun() }
    private val moon: CelestialBody by lazy { CelestialBodyFactory.getMoon() }

    override fun apparentSunMoonTopocentric(observer: Observer, time: ZonedDateTime): SunMoonApparent {
        val date = time.toAbsoluteDateUtc()
        val topo = TopocentricFrame(
            earth,
            GeodeticPoint(
                FastMath.toRadians(observer.latitudeDeg),
                FastMath.toRadians(observer.longitudeDeg),
                observer.elevationMeters
            ),
            "observer"
        )

        val sunPv = sun.getPVCoordinates(date, inertialFrame)
        val moonPv = moon.getPVCoordinates(date, inertialFrame)

        val sunPos = sunPv.position
        val moonPos = moonPv.position

        val sunAzGeom = FastMath.toDegrees(topo.getAzimuth(sunPos, inertialFrame, date)).normalize360()
        val sunAltGeom = FastMath.toDegrees(topo.getElevation(sunPos, inertialFrame, date))
        val moonAzGeom = FastMath.toDegrees(topo.getAzimuth(moonPos, inertialFrame, date)).normalize360()
        val moonAltGeom = FastMath.toDegrees(topo.getElevation(moonPos, inertialFrame, date))

        val sunAltApp = if (applyAtmosphericRefraction) {
            sunAltGeom + standardRefractionDeg(sunAltGeom, observer.pressureHpa, observer.temperatureC)
        } else sunAltGeom

        val moonAltApp = if (applyAtmosphericRefraction) {
            moonAltGeom + standardRefractionDeg(moonAltGeom, observer.pressureHpa, observer.temperatureC)
        } else moonAltGeom

        val sunRange = topoRangeMeters(topo, sunPos, date)
        val moonRange = topoRangeMeters(topo, moonPos, date)

        return SunMoonApparent(
            sunAzimuthDeg = sunAzGeom,
            sunAltitudeDeg = sunAltApp,
            moonAzimuthDeg = moonAzGeom,
            moonAltitudeDeg = moonAltApp,
            sunApparentRadiusDeg = angularRadiusDeg(SUN_MEAN_RADIUS_M, sunRange),
            moonApparentRadiusDeg = angularRadiusDeg(MOON_MEAN_RADIUS_M, moonRange)
        )
    }

    private fun topoRangeMeters(topo: TopocentricFrame, pos: Vector3D, date: AbsoluteDate): Double =
        topo.getRange(pos, inertialFrame, date)

    companion object {
        private const val SUN_MEAN_RADIUS_M = 695_700_000.0
        private const val MOON_MEAN_RADIUS_M = 1_737_400.0

        /**
         * يهيئ Orekit من مجلد أو ملف zip.
         * يمكن استدعاؤها مرة عند تشغيل التطبيق قبل إنشاء provider.
         */
        fun initializeData(dataPath: File) {
            val manager = DataContext.getDefault().dataProvidersManager
            if (dataPath.isDirectory) {
                manager.addProvider(DirectoryCrawler(dataPath))
            } else {
                manager.addProvider(ZipJarCrawler(dataPath))
            }
        }

        fun create(
            dataPath: File,
            applyAtmosphericRefraction: Boolean = true
        ): OrekitEphemerisProvider {
            initializeData(dataPath)
            return OrekitEphemerisProvider(applyAtmosphericRefraction = applyAtmosphericRefraction)
        }
    }
}

private fun ZonedDateTime.toAbsoluteDateUtc(): AbsoluteDate {
    val u = withZoneSameInstant(ZoneOffset.UTC)
    return AbsoluteDate(
        u.year,
        u.monthValue,
        u.dayOfMonth,
        u.hour,
        u.minute,
        u.second + u.nano / 1_000_000_000.0,
        TimeScalesFactory.getUTC()
    )
}

private fun Double.normalize360(): Double {
    var x = this % 360.0
    if (x < 0.0) x += 360.0
    return x
}

private fun angularRadiusDeg(radiusMeters: Double, distanceMeters: Double): Double =
    FastMath.toDegrees(FastMath.asin((radiusMeters / distanceMeters).coerceIn(-1.0, 1.0)))

/**
 * انكسار جوي قياسي بصيغة Bennett/Sæmundsson تقريبية.
 * صالحة أساساً قرب الأفق وفوقه بقليل، ونقيدها لتجنب انفجار tangent تحت الأفق كثيراً.
 */
private fun standardRefractionDeg(altitudeDeg: Double, pressureHpa: Double, temperatureC: Double): Double {
    if (altitudeDeg < -2.0 || altitudeDeg > 89.0) return 0.0
    val h = altitudeDeg
    val rArcMin = 1.02 / tan((h + 10.3 / (h + 5.11)) * PI / 180.0)
    val scale = (pressureHpa / 1010.0) * (283.0 / (273.0 + temperatureC))
    return (rArcMin / 60.0) * scale
}
