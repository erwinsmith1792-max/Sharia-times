package ai.arena.shariaastro

import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * نتيجة اقتران قمري-شمسي حسب التعريف المعتمد:
 * مرور مركز القمر بالقوس العمودي على مسار الشمس اليومي الظاهري والمار من مركز الشمس، بالنسبة للمراقب.
 */
data class LunarSolarConjunction(
    val time: ZonedDateTime,
    /** البعد الزاوي بين مركزي الشمس والقمر عند لحظة الجذر. */
    val elongationDeg: Double,
    /** قيمة دالة الجذر النهائية للتشخيص. */
    val diagnosticValue: Double
)

data class ConjunctionOptions(
    val scanStep: Duration = Duration.ofHours(2),
    val tolerance: Duration = Duration.ofMillis(500),
    /** فرق الزمن المستخدم لتقدير مماس مسار الشمس اليومي الظاهري. */
    val tangentDelta: Duration = Duration.ofMinutes(2),
    /**
     * لأن شرط القوس العمودي وحده قد يحدث كثيراً، نحتفظ فقط بالجذور القريبة من الاقتران الشهري.
     * يمكن ضبطه بعد الاختبارات. قيمة 15° واسعة بما يكفي كبداية.
     */
    val maxElongationDeg: Double = 15.0,
    /** دمج الجذور المتقاربة زمنياً لتجنب التكرار العددي. */
    val mergeWindow: Duration = Duration.ofHours(18)
)

class LunarSolarConjunctionCalculator(
    private val ephemeris: EphemerisProvider,
    private val observer: Observer,
    private val zone: ZoneId,
    private val options: ConjunctionOptions = ConjunctionOptions()
) {
    /** يحسب اقترانات السنة المدنية المحلية المدخلة. */
    fun conjunctionsForYear(year: Int): List<LunarSolarConjunction> {
        val start = ZonedDateTime.of(LocalDateTime.of(year, 1, 1, 0, 0), zone).minusDays(2)
        val end = ZonedDateTime.of(LocalDateTime.of(year + 1, 1, 1, 0, 0), zone).plusDays(2)
        val roots = roots(start, end, ::arcCondition)
            .map { t -> LunarSolarConjunction(t, elongationDeg(t), arcCondition(t)) }
            .filter { it.elongationDeg <= options.maxElongationDeg }
            .sortedBy { it.time.toInstant() }

        return mergeCloseRoots(roots)
            .filter { it.time.year == year }
    }

    /** المدد الشرعية بين الاقترانات: تُقاس زمنياً، ويمكن عرضها لاحقاً كساعات/أيام شرعية عبر ShariaTimeEngine لكل موقع. */
    fun durationsBetween(conjunctions: List<LunarSolarConjunction>): List<Duration> =
        conjunctions.zipWithNext { a, b -> Duration.between(a.time.toInstant(), b.time.toInstant()) }

    /**
     * دالة الجذر:
     * نكوّن متجه مماس مسار الشمس اليومي apparent topocentric، ثم نأخذ dot(moon, tangent).
     * القوس العمودي على مسار الشمس والمار من الشمس هو دائرة عظمى مستواها عمودي على tangent.
     * يقع القمر على هذا القوس عندما dot(moonVector, tangentVector)=0.
     */
    private fun arcCondition(t: ZonedDateTime): Double {
        val dt = options.tangentDelta
        val sunBefore = sunVector(t.minus(dt))
        val sunAfter = sunVector(t.plus(dt))
        val tangent = normalize(sunAfter - sunBefore)
        val moon = moonVector(t)
        return dot(moon, tangent)
    }

    private fun elongationDeg(t: ZonedDateTime): Double {
        val s = sunVector(t)
        val m = moonVector(t)
        val c = dot(s, m).coerceIn(-1.0, 1.0)
        return acos(c) * 180.0 / PI
    }

    private fun sunVector(t: ZonedDateTime): Vec3 {
        val x = ephemeris.apparentSunMoonTopocentric(observer, t)
        return horizonVector(x.sunAzimuthDeg, x.sunAltitudeDeg)
    }

    private fun moonVector(t: ZonedDateTime): Vec3 {
        val x = ephemeris.apparentSunMoonTopocentric(observer, t)
        return horizonVector(x.moonAzimuthDeg, x.moonAltitudeDeg)
    }

    private fun horizonVector(azDeg: Double, altDeg: Double): Vec3 {
        val az = azDeg * PI / 180.0
        val alt = altDeg * PI / 180.0
        // x شرق، y شمال، z أعلى. Azimuth من الشمال مع عقارب الساعة.
        return Vec3(
            x = cos(alt) * sin(az),
            y = cos(alt) * cos(az),
            z = sin(alt)
        )
    }

    private fun roots(start: ZonedDateTime, end: ZonedDateTime, f: (ZonedDateTime) -> Double): List<ZonedDateTime> {
        val out = mutableListOf<ZonedDateTime>()
        var t0 = start
        var y0 = f(t0)
        while (t0.isBefore(end)) {
            val t1 = if (t0.plus(options.scanStep).isBefore(end)) t0.plus(options.scanStep) else end
            val y1 = f(t1)
            if (y0 * y1 < 0.0) out += bisect(t0, t1, y0, y1, f)
            t0 = t1
            y0 = y1
        }
        return out
    }

    private fun bisect(a0: ZonedDateTime, b0: ZonedDateTime, fa0: Double, fb0: Double, f: (ZonedDateTime) -> Double): ZonedDateTime {
        var a = a0
        var b = b0
        var fa = fa0
        while (Duration.between(a, b) > options.tolerance) {
            val mid = a.plusNanos(Duration.between(a, b).toNanos() / 2)
            val fm = f(mid)
            if (fa * fm <= 0.0) {
                b = mid
            } else {
                a = mid
                fa = fm
            }
        }
        return a.plusNanos(Duration.between(a, b).toNanos() / 2)
    }

    private fun mergeCloseRoots(xs: List<LunarSolarConjunction>): List<LunarSolarConjunction> {
        if (xs.isEmpty()) return xs
        val out = mutableListOf<LunarSolarConjunction>()
        var group = mutableListOf(xs.first())
        for (x in xs.drop(1)) {
            if (Duration.between(group.last().time, x.time) <= options.mergeWindow) {
                group += x
            } else {
                out += group.minByOrNull { it.elongationDeg }!!
                group = mutableListOf(x)
            }
        }
        out += group.minByOrNull { it.elongationDeg }!!
        return out
    }

    private data class Vec3(val x: Double, val y: Double, val z: Double) {
        operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    }

    private fun dot(a: Vec3, b: Vec3): Double = a.x * b.x + a.y * b.y + a.z * b.z
    private fun normalize(v: Vec3): Vec3 {
        val n = sqrt(dot(v, v))
        return Vec3(v.x / n, v.y / n, v.z / n)
    }
}
