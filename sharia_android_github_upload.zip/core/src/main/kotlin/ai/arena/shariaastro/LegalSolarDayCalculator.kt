package ai.arena.shariaastro

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.abs

sealed class LegalSolarDayResult {
    data class Success(val anchors: LegalSolarAnchors, val warnings: List<String> = emptyList()) : LegalSolarDayResult()
    data class Failure(val errors: List<String>, val partialWarnings: List<String> = emptyList()) : LegalSolarDayResult()
}

/**
 * يبني مراسي اليوم الشرعي من الباحث الفلكي العددي.
 */
class LegalSolarDayCalculator(
    ephemeris: EphemerisProvider,
    observer: Observer,
    private val zone: ZoneId,
    options: SolarEventOptions = SolarEventOptions()
) {
    private val finder = SolarAzimuthEventFinder(ephemeris, observer, options)

    fun calculate(date: LocalDate): LegalSolarDayResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        val sunrise = finder.findLegalSunrise(date, zone)?.time
            ?: run { errors += "تعذر إيجاد الشروق الشرعي في هذا التاريخ والموقع."; null }
        val sunset = finder.findLegalSunset(date, zone)?.time
            ?: run { errors += "تعذر إيجاد الغروب الشرعي في هذا التاريخ والموقع."; null }

        if (sunrise == null || sunset == null) return LegalSolarDayResult.Failure(errors, warnings)

        val noon = finder.findCenterAzimuth180(sunrise, sunset, aboveHorizon = true, closestTo = midpoint(sunrise, sunset))?.time
            ?: run { errors += "تعذر إيجاد الظهر الشرعي: مركز الشمس لم يقطع Azimuth=180° فوق الأفق بين الشروق والغروب."; null }

        if (noon == null) return LegalSolarDayResult.Failure(errors, warnings)

        val officialMidnight = ZonedDateTime.of(date, LocalTime.MIDNIGHT, zone)
        val nextOfficialMidnight = officialMidnight.plusDays(1)

        val legalMidnight = finder.findCenterAzimuth180(
            officialMidnight.minusHours(18),
            officialMidnight.plusHours(18),
            aboveHorizon = false,
            closestTo = officialMidnight
        )?.time ?: run {
            errors += "تعذر إيجاد منتصف الليل الشرعي القريب من منتصف الليل الرسمي: مركز الشمس لم يقطع Azimuth=180° تحت الأفق في نافذة البحث."
            null
        }

        val nextLegalMidnight = finder.findCenterAzimuth180(
            nextOfficialMidnight.minusHours(18),
            nextOfficialMidnight.plusHours(18),
            aboveHorizon = false,
            closestTo = nextOfficialMidnight
        )?.time ?: run {
            errors += "تعذر إيجاد منتصف الليل الشرعي القريب من منتصف الليل الرسمي التالي."
            null
        }

        if (legalMidnight == null || nextLegalMidnight == null) {
            return LegalSolarDayResult.Failure(errors, warnings)
        }

        val dhuhrPrayer = finder.findDhuhrPrayerStartAfter(noon, sunset)?.time
        if (dhuhrPrayer == null) {
            warnings += "لم يُعثر على لحظة تماس حافة الشمس مع خط Azimuth=180° من جهة الغرب؛ سيستخدم التطبيق وقت مركز الشمس كقيمة مؤقتة لصلاة الظهر."
        }

        val anchors = LegalSolarAnchors(
            sunrise = sunrise,
            noon = noon,
            sunset = sunset,
            legalMidnightNearOfficialMidnight = legalMidnight,
            legalMidnightNearNextOfficialMidnight = nextLegalMidnight,
            dhuhrPrayerStart = dhuhrPrayer
        )
        return LegalSolarDayResult.Success(anchors, warnings)
    }

    private fun midpoint(a: ZonedDateTime, b: ZonedDateTime): ZonedDateTime =
        a.plusNanos(java.time.Duration.between(a, b).toNanos() / 2)
}
