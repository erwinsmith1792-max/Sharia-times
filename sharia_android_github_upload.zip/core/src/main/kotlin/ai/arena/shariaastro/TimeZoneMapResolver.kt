package ai.arena.shariaastro

import us.dustinj.timezonemap.TimeZoneMap
import java.time.ZoneId
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * محدد منطقة زمنية offline من الإحداثيات اعتماداً على Timezone Boundary Builder عبر مكتبة timezonemap.
 *
 * الفكرة:
 * - لا نحمّل خريطة العالم كاملة من البداية.
 * - نبني خريطة لمنطقة صغيرة حول النقطة ثم نوسعها عند الحاجة.
 * - النتيجة هي IANA ZoneId مثل Africa/Tunis، ومن ثم java.time يتكفل بالتوقيت الصيفي تاريخياً.
 */
class TimeZoneMapResolver(
    private val initialRadiusDeg: Double = 2.0,
    private val maxRadiusDeg: Double = 45.0
) : TimeZoneResolver {

    private val cache = ConcurrentHashMap<RegionKey, TimeZoneMap>()

    override fun resolve(latitudeDeg: Double, longitudeDeg: Double): ZoneId {
        require(latitudeDeg in -90.0..90.0) { "خط العرض خارج المجال: $latitudeDeg" }
        require(longitudeDeg in -180.0..180.0) { "خط الطول خارج المجال: $longitudeDeg" }

        var radius = initialRadiusDeg
        while (radius <= maxRadiusDeg) {
            val south = max(-90.0, latitudeDeg - radius)
            val north = min(90.0, latitudeDeg + radius)
            val west = max(-180.0, longitudeDeg - radius)
            val east = min(180.0, longitudeDeg + radius)

            val key = RegionKey(south.roundKey(), west.roundKey(), north.roundKey(), east.roundKey())
            val map = cache.getOrPut(key) {
                TimeZoneMap.forRegion(south, west, north, east)
            }
            val zone = map.getOverlappingTimeZone(latitudeDeg, longitudeDeg)
            if (zone.isPresent) return ZoneId.of(zone.get().zoneId)

            radius *= 2.0
        }

        // ملاذ أخير: تحميل شريط عالمي حسب خط العرض. أثقل من المنطقة الصغيرة لكنه يزيد فرصة النجاح قرب الحدود/البحار.
        val south = max(-90.0, latitudeDeg - maxRadiusDeg)
        val north = min(90.0, latitudeDeg + maxRadiusDeg)
        val key = RegionKey(south.roundKey(), -180.0, north.roundKey(), 180.0)
        val globalBand = cache.getOrPut(key) {
            TimeZoneMap.forRegion(south, -180.0, north, 180.0)
        }
        val zone = globalBand.getOverlappingTimeZone(latitudeDeg, longitudeDeg)
        if (zone.isPresent) return ZoneId.of(zone.get().zoneId)

        throw IllegalStateException("تعذر تحديد المنطقة الزمنية من الإحداثيات: $latitudeDeg, $longitudeDeg")
    }

    private data class RegionKey(val south: Double, val west: Double, val north: Double, val east: Double)

    private fun Double.roundKey(): Double = kotlin.math.round(this * 10.0) / 10.0
}
