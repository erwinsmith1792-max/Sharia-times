package ai.arena.shariaastro

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.ZoneId

/** نتيجة البحث الجغرافي. */
data class ResolvedPlace(
    val displayName: String,
    val latitudeDeg: Double,
    val longitudeDeg: Double,
    /** حالياً يملأها التطبيق لاحقاً عبر Timezone Boundary Builder أو خدمة timezone. */
    val zoneId: ZoneId? = null,
    val elevationMeters: Double = 0.0
)

interface GeoResolver {
    fun resolvePlace(name: String, language: String = "ar"): List<ResolvedPlace>
}

/**
 * عميل بسيط لـ OpenStreetMap/Nominatim.
 * تنبيه: Nominatim العام له سياسة استخدام؛ في التطبيق النهائي الأفضل وضع endpoint خاص أو مزود تجاري/مخدم وسيط.
 */
class NominatimGeoResolver(
    private val endpoint: String = "https://nominatim.openstreetmap.org/search",
    private val userAgent: String = "ShariaAstro/0.1 contact@example.com"
) : GeoResolver {
    override fun resolvePlace(name: String, language: String): List<ResolvedPlace> {
        val q = URLEncoder.encode(name, StandardCharsets.UTF_8.name())
        val url = URL("$endpoint?q=$q&format=jsonv2&limit=5&accept-language=$language")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("User-Agent", userAgent)
        }
        val text = conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        val arr = JSONArray(text)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    ResolvedPlace(
                        displayName = o.optString("display_name"),
                        latitudeDeg = o.getString("lat").toDouble(),
                        longitudeDeg = o.getString("lon").toDouble()
                    )
                )
            }
        }
    }
}

/**
 * واجهة تحديد المنطقة الزمنية من الإحداثيات.
 * التنفيذ النهائي المقترح: Timezone Boundary Builder محلياً، أو API وسيط يرجع IANA zone id.
 */
interface TimeZoneResolver {
    fun resolve(latitudeDeg: Double, longitudeDeg: Double): ZoneId
}
