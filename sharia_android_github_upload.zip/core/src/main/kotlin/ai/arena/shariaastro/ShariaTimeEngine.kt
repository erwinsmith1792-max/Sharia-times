package ai.arena.shariaastro

import java.time.Duration
import java.time.ZonedDateTime
import kotlin.math.abs

/**
 * مخرجات الحساب الفلكي ليوم شرعي حول تاريخ محلي.
 * كل القيم ZonedDateTime للحفاظ على المنطقة الزمنية و DST.
 */
data class LegalSolarAnchors(
    val sunrise: ZonedDateTime,
    /** وقت الظهر/منتصف النهار الشرعي: مركز الشمس على Azimuth=180° وهي فوق الأفق. */
    val noon: ZonedDateTime,
    val sunset: ZonedDateTime,
    /** أقرب منتصف ليل شرعي إلى منتصف الليل الرسمي في التاريخ المحلي. */
    val legalMidnightNearOfficialMidnight: ZonedDateTime,
    /** أقرب منتصف ليل شرعي إلى منتصف الليل الرسمي في اليوم التالي. */
    val legalMidnightNearNextOfficialMidnight: ZonedDateTime,
    /** دخول صلاة الظهر: حافة الشمس مماسة لخط Azimuth=180° من جهة الغرب أثناء النهار. */
    val dhuhrPrayerStart: ZonedDateTime? = null
)

data class ShariaHourSegments(
    val delta1: Duration, // (noon - sunrise) / 5
    val delta2: Duration, // (sunset - noon) / 6
    val delta3: Duration, // (nextLegalMidnight - sunset) / 6
    val delta4: Duration, // (d - legalMidnight) / 6
    val fajrD: ZonedDateTime
)

enum class DayNight { DAY, NIGHT }

data class ShariaTimeResult(
    /** القيمة بالساعات الشرعية، وقد تكون كسرية. */
    val value: Double,
    val label: String,
    val dayNight: DayNight,
    val segment: String
)

object ShariaTimeEngine {
    private const val EPS_HOURS = 1e-7

    fun segments(a: LegalSolarAnchors): ShariaHourSegments {
        val d1 = div(durationBetween(a.sunrise, a.noon), 5.0)
        val d2 = div(durationBetween(a.noon, a.sunset), 6.0)
        val d = a.sunrise.minus(d1)
        val d4 = div(durationBetween(a.legalMidnightNearOfficialMidnight, d), 6.0)
        val d3 = div(durationBetween(a.sunset, a.legalMidnightNearNextOfficialMidnight), 6.0)
        return ShariaHourSegments(delta1 = d1, delta2 = d2, delta3 = d3, delta4 = d4, fajrD = d)
    }

    /**
     * يحسب الوقت الشرعي للتوقيت المحلي المدخل وفق التقسيمات المذكورة.
     * ملاحظة: للفترة D..sunrise اعتُمد التصحيح المنطقي: (input - D) / delta1.
     */
    fun compute(input: ZonedDateTime, a: LegalSolarAnchors): ShariaTimeResult {
        val s = segments(a)
        val t = input

        return when {
            !t.isBefore(a.sunrise) && !t.isAfter(a.noon) -> {
                val v = durationBetween(a.sunrise, t).toMillis().toDouble() / s.delta1.toMillis() + 1.0
                ShariaTimeResult(v, daytimeLabel(v, mapOf(1.0 to "طلوع الشمس", 5.0 to "بداية الضحى", 6.0 to "تمام الضحى وبداية الظهر")), DayNight.DAY, "sunrise-noon")
            }

            !t.isBefore(a.noon) && !t.isAfter(a.sunset) -> {
                val v = durationBetween(a.noon, t).toMillis().toDouble() / s.delta2.toMillis() + 6.0
                ShariaTimeResult(v, daytimeLabel(v, mapOf(6.0 to "تمام الضحى وبداية الظهر", 9.0 to "نهاية الظهر وبداية العصر", 12.0 to "الغروب")), DayNight.DAY, "noon-sunset")
            }

            !t.isBefore(a.sunset) -> {
                val v = durationBetween(a.sunset, t).toMillis().toDouble() / s.delta3.toMillis()
                ShariaTimeResult(v, nighttimeLabel(v, mapOf(0.0 to "الغروب", 1.0 to "بداية العشاء", 6.0 to "منتصف الليل")), DayNight.NIGHT, "sunset-next-midnight")
            }

            !t.isBefore(a.legalMidnightNearOfficialMidnight) && t.isBefore(s.fajrD) -> {
                val v = durationBetween(a.legalMidnightNearOfficialMidnight, t).toMillis().toDouble() / s.delta4.toMillis() + 6.0
                ShariaTimeResult(v, nighttimeLabel(v, mapOf(6.0 to "الغسق / منتصف الليل الشرعي", 9.0 to "دخول الربع الأخير من الليل", 12.0 to "مطلع الفجر")), DayNight.NIGHT, "midnight-d")
            }

            !t.isBefore(s.fajrD) && t.isBefore(a.sunrise) -> {
                val v = durationBetween(s.fajrD, t).toMillis().toDouble() / s.delta1.toMillis()
                val label = when {
                    near(v, 0.0) -> "مطلع الفجر"
                    near(v, 1.0) -> "طلوع الشمس"
                    else -> format(v) + " نهاراً"
                }
                ShariaTimeResult(v, label, DayNight.DAY, "d-sunrise")
            }

            else -> {
                // إذا وقع input قبل منتصف الليل الشرعي القريب بسبب حالات نادرة في خطوط العرض العالية.
                val v = durationBetween(a.legalMidnightNearOfficialMidnight, t).toMillis().toDouble() / s.delta4.toMillis() + 6.0
                ShariaTimeResult(v, format(v) + " ليلاً", DayNight.NIGHT, "fallback")
            }
        }
    }

    fun prayerTimes(a: LegalSolarAnchors): PrayerTimes {
        val s = segments(a)
        val asrStartBase = a.noon.plus(mul(s.delta2, 3.0)) // 9 ساعات شرعية: نهاية الظهر وبداية العصر
        val quarterAsr = div(s.delta2, 4.0)
        return PrayerTimes(
            fajrStart = s.fajrD,
            fajrEnd = a.sunrise,
            dhuhrStart = a.dhuhrPrayerStart ?: a.noon, // دخول صلاة الظهر: تماس حافة الشمس مع خط Azimuth=180° من جهة الغرب، أو noon مؤقتاً إن لم يزودها الحاسب الفلكي
            dhuhrEnd = asrStartBase,
            asrStart = asrStartBase.plus(quarterAsr),
            asrEnd = a.sunset.minus(quarterAsr),
            maghribStart = a.sunset,
            maghribEnd = a.sunset.plus(s.delta3),
            ishaStart = a.sunset.plus(s.delta3),
            ishaEnd = s.fajrD.minus(s.delta1)
        )
    }

    private fun daytimeLabel(v: Double, exact: Map<Double, String>): String =
        exact.entries.firstOrNull { near(v, it.key) }?.value ?: (format(v) + " نهاراً")

    private fun nighttimeLabel(v: Double, exact: Map<Double, String>): String =
        exact.entries.firstOrNull { near(v, it.key) }?.value ?: (format(v) + " ليلاً")

    private fun near(a: Double, b: Double) = abs(a - b) < EPS_HOURS

    private fun format(v: Double): String = "%.6f ساعة شرعية".format(v)

    private fun durationBetween(a: ZonedDateTime, b: ZonedDateTime): Duration = Duration.between(a.toInstant(), b.toInstant())

    private fun div(d: Duration, x: Double): Duration = Duration.ofNanos((d.toNanos() / x).toLong())

    private fun mul(d: Duration, x: Double): Duration = Duration.ofNanos((d.toNanos() * x).toLong())
}

data class PrayerTimes(
    val fajrStart: ZonedDateTime,
    val fajrEnd: ZonedDateTime,
    val dhuhrStart: ZonedDateTime,
    val dhuhrEnd: ZonedDateTime,
    val asrStart: ZonedDateTime,
    val asrEnd: ZonedDateTime,
    val maghribStart: ZonedDateTime,
    val maghribEnd: ZonedDateTime,
    val ishaStart: ZonedDateTime,
    val ishaEnd: ZonedDateTime
)

/**
 * واجهة لاحقة للحساب الفلكي عالي الدقة.
 * تعريف خط السمت 180 المعتمد في هذا المشروع: Azimuth = 180°، وليس مجرد عبور الزوال.
 */
interface EphemerisProvider {
    fun apparentSunMoonTopocentric(observer: Observer, time: ZonedDateTime): SunMoonApparent
}

data class Observer(
    val latitudeDeg: Double,
    val longitudeDeg: Double,
    val elevationMeters: Double = 0.0,
    val temperatureC: Double = 15.0,
    val pressureHpa: Double = 1013.25
)

data class SunMoonApparent(
    val sunAzimuthDeg: Double,
    val sunAltitudeDeg: Double,
    val moonAzimuthDeg: Double,
    val moonAltitudeDeg: Double,
    val sunApparentRadiusDeg: Double,
    val moonApparentRadiusDeg: Double
)
