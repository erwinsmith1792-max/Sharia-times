package ai.arena.shariaastro

import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin

/** إعدادات نموذج الأفق والشمس. */
data class SolarEventOptions(
    /** خطوة المسح الأولي. تُصغّر تلقائياً بالبسكشن عند إيجاد جذر. */
    val scanStep: Duration = Duration.ofMinutes(5),
    /** دقة زمنية نهائية تقريبية. */
    val tolerance: Duration = Duration.ofMillis(250),
    /**
     * انخفاض الأفق المحلي بالدرجات. 0 للأفق الظاهري القياسي.
     * إذا أُدخل ارتفاع الموقع يمكن للحاسب الفلكي الخارجي تضمين dip أو يضبط هذا الحقل لاحقاً.
     */
    val horizonAltitudeDeg: Double = 0.0
)

enum class SolarEventKind {
    LEGAL_SUNRISE,
    LEGAL_SUNSET,
    /** مركز الشمس على Azimuth=180° وهي فوق الأفق. */
    LEGAL_NOON_AZ_180,
    /** مركز الشمس على Azimuth=180° وهي تحت الأفق. */
    LEGAL_MIDNIGHT_AZ_180,
    /** حافة الشمس مماسة لخط Azimuth=180° من جهة الغرب أثناء النهار. */
    DHUHR_PRAYER_WEST_LIMB_TOUCH_AZ_180
}

data class SolarEvent(
    val kind: SolarEventKind,
    val time: ZonedDateTime,
    val diagnosticValue: Double
)

/**
 * باحث عددي عام للأحداث الشمسية المعتمدة على topocentric apparent Sun.
 *
 * مهم: هذه الوحدة لا تحسب موقع الشمس بنفسها؛ بل تعتمد على EphemerisProvider.
 * لاحقاً نربط EphemerisProvider بـ Orekit/JPL أو SPICE.
 */
class SolarAzimuthEventFinder(
    private val ephemeris: EphemerisProvider,
    private val observer: Observer,
    private val options: SolarEventOptions = SolarEventOptions()
) {
    fun findLegalSunrise(date: LocalDate, zone: java.time.ZoneId): SolarEvent? {
        val start = ZonedDateTime.of(date, LocalTime.MIDNIGHT, zone)
        val end = start.plusDays(1)
        return roots(start, end, ::upperLimbAltitudeMinusHorizon)
            .filter { isRisingAround(it) }
            .minByOrNull { abs(Duration.between(start.plusHours(6), it).toMillis()) }
            ?.let { SolarEvent(SolarEventKind.LEGAL_SUNRISE, it, upperLimbAltitudeMinusHorizon(it)) }
    }

    fun findLegalSunset(date: LocalDate, zone: java.time.ZoneId): SolarEvent? {
        val start = ZonedDateTime.of(date, LocalTime.MIDNIGHT, zone)
        val end = start.plusDays(1)
        return roots(start, end, ::upperLimbAltitudeMinusHorizon)
            .filter { !isRisingAround(it) }
            .minByOrNull { abs(Duration.between(start.plusHours(18), it).toMillis()) }
            ?.let { SolarEvent(SolarEventKind.LEGAL_SUNSET, it, upperLimbAltitudeMinusHorizon(it)) }
    }

    /** مركز الشمس على Azimuth=180° مع شرط الارتفاع فوق/تحت الأفق. */
    fun findCenterAzimuth180(
        start: ZonedDateTime,
        end: ZonedDateTime,
        aboveHorizon: Boolean,
        closestTo: ZonedDateTime? = null
    ): SolarEvent? {
        val kind = if (aboveHorizon) SolarEventKind.LEGAL_NOON_AZ_180 else SolarEventKind.LEGAL_MIDNIGHT_AZ_180
        val candidates = roots(start, end) { t -> signedAzimuthDeltaFrom180Deg(t) }
            .filter { t ->
                val sun = ephemeris.apparentSunMoonTopocentric(observer, t)
                if (aboveHorizon) sun.sunAltitudeDeg > 0.0 else sun.sunAltitudeDeg < 0.0
            }
        val selected = when {
            candidates.isEmpty() -> null
            closestTo != null -> candidates.minByOrNull { abs(Duration.between(closestTo, it).toMillis()) }
            else -> candidates.first()
        }
        return selected?.let { SolarEvent(kind, it, signedAzimuthDeltaFrom180Deg(it)) }
    }

    /**
     * دخول صلاة الظهر: حافة الشمس مماسة لخط Azimuth=180° من جهة الغرب أثناء النهار.
     *
     * نمذجتها هنا: المسافة الزاوية الموقعة بين مركز الشمس والدائرة الرأسية Az=180° تساوي نصف قطر الشمس.
     * الإشارة الموجبة تعني أن المركز في جهة الغرب من خط الجنوب وفق اصطلاح azimuth من الشمال باتجاه الشرق، أي azimuth > 180° قرب الجنوب.
     */
    fun findDhuhrPrayerStartAfter(noon: ZonedDateTime, latest: ZonedDateTime): SolarEvent? {
        return roots(noon, latest) { t -> westSignedDistanceFromAz180Deg(t) - sunRadiusDeg(t) }
            .filter { t -> ephemeris.apparentSunMoonTopocentric(observer, t).sunAltitudeDeg > 0.0 }
            .firstOrNull()
            ?.let { SolarEvent(SolarEventKind.DHUHR_PRAYER_WEST_LIMB_TOUCH_AZ_180, it, westSignedDistanceFromAz180Deg(it) - sunRadiusDeg(it)) }
    }

    private fun upperLimbAltitudeMinusHorizon(t: ZonedDateTime): Double {
        val s = ephemeris.apparentSunMoonTopocentric(observer, t)
        // إذا كان altitude ظاهرياً لمركز الشمس، فتماس الحافة العليا مع الأفق يعني altitude + radius = horizonAltitude.
        return s.sunAltitudeDeg + s.sunApparentRadiusDeg - options.horizonAltitudeDeg
    }

    private fun sunRadiusDeg(t: ZonedDateTime): Double = ephemeris.apparentSunMoonTopocentric(observer, t).sunApparentRadiusDeg

    private fun signedAzimuthDeltaFrom180Deg(t: ZonedDateTime): Double {
        val az = ephemeris.apparentSunMoonTopocentric(observer, t).sunAzimuthDeg
        return normalizeSignedDeg(az - 180.0)
    }

    private fun westSignedDistanceFromAz180Deg(t: ZonedDateTime): Double {
        val s = ephemeris.apparentSunMoonTopocentric(observer, t)
        val altRad = s.sunAltitudeDeg.toRad()
        val dAzRad = normalizeSignedDeg(s.sunAzimuthDeg - 180.0).toRad()
        // cross-track angular distance to the vertical great circle at Az=180°.
        return asin(cos(altRad) * sin(dAzRad)).toDeg()
    }

    private fun isRisingAround(t: ZonedDateTime): Boolean {
        val before = t.minusMinutes(2)
        val after = t.plusMinutes(2)
        return upperLimbAltitudeMinusHorizon(after) > upperLimbAltitudeMinusHorizon(before)
    }

    private fun roots(start: ZonedDateTime, end: ZonedDateTime, f: (ZonedDateTime) -> Double): List<ZonedDateTime> {
        val out = mutableListOf<ZonedDateTime>()
        var t0 = start
        var y0 = f(t0)
        while (t0.isBefore(end)) {
            val t1 = minOfZdt(t0.plus(options.scanStep), end)
            val y1 = f(t1)
            if (y0 == 0.0) out += t0
            if (y0 * y1 < 0.0) out += bisect(t0, t1, y0, y1, f)
            t0 = t1
            y0 = y1
        }
        return out.distinctBy { it.toInstant().epochSecond }
    }

    private fun bisect(a0: ZonedDateTime, b0: ZonedDateTime, fa0: Double, fb0: Double, f: (ZonedDateTime) -> Double): ZonedDateTime {
        var a = a0
        var b = b0
        var fa = fa0
        var fb = fb0
        while (Duration.between(a, b).abs() > options.tolerance) {
            val mid = a.plusNanos(Duration.between(a, b).toNanos() / 2)
            val fm = f(mid)
            if (fa * fm <= 0.0) {
                b = mid
                fb = fm
            } else {
                a = mid
                fa = fm
            }
        }
        return a.plusNanos(Duration.between(a, b).toNanos() / 2)
    }

    private fun minOfZdt(a: ZonedDateTime, b: ZonedDateTime): ZonedDateTime = if (a.isBefore(b)) a else b

    private fun normalizeSignedDeg(x: Double): Double {
        var y = (x + 180.0) % 360.0
        if (y < 0) y += 360.0
        return y - 180.0
    }

    private fun Double.toRad(): Double = this * PI / 180.0
    private fun Double.toDeg(): Double = this * 180.0 / PI
}
